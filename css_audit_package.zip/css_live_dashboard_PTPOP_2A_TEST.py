from __future__ import annotations
import sys, time, random, json
from datetime import datetime
from pathlib import Path
from typing import Dict, Tuple

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from backend.data.coinbase_historical_downloader import load_runtime_asset
from backend.execution.position_manager import PositionManager
from backend.app.brokers.futures_sim_adapter import FuturesSimAdapter
from backend.app.risk.futures_position_manager import FuturesPositionManager
from backend.scanner.options_chain_adapter import OptionsChainAdapter
from backend.options.options_position_manager import OptionsPositionManager
from backend.options.options_intelligence_engine import OptionsIntelligenceEngine

# ============================================================
# STATE / FILES
# ============================================================

STATE_DIR = PROJECT_ROOT / "artifacts"
STATE_DIR.mkdir(exist_ok=True)

FUTURES_BIAS_FILE = STATE_DIR / "futures_symbol_bias.json"
FUTURES_LOSS_FILE = STATE_DIR / "futures_loss_streak.json"

# ============================================================
# SYMBOL SETS
# ============================================================

SYMBOLS = [
    "BTC-USD","ETH-USD","SOL-USD","XRP-USD","ADA-USD",
    "DOGE-USD","AVAX-USD","LINK-USD","LTC-USD","BCH-USD"
]

FUTURES_SYMBOLS = ["ES","NQ","CL","GC"]

FX_SYMBOLS = [
    "EUR_USD","GBP_USD","USD_JPY","USD_CHF",
    "AUD_USD","USD_CAD","NZD_USD",
    "EUR_GBP","EUR_JPY","GBP_JPY"
]

OPTION_SYMBOLS = ["AAPL-C","SPY-C","QQQ-C"]

CYCLE_SLEEP = 8

# ============================================================
# REINFORCEMENT CONFIG
# ============================================================

BIAS_NEUTRAL = 1.0
BIAS_MIN = 0.35
BIAS_MAX = 2.25
BIAS_DECAY_RATE = 0.06
BIAS_REWARD_MULT = 1.10
BIAS_LOSS_PENALTY_1 = 0.88
BIAS_LOSS_PENALTY_2 = 0.78
BIAS_LOSS_PENALTY_3 = 0.68

CAPITAL_MULTIPLIERS = {
    "BLOCK":0.0,
    "REDUCE":0.5,
    "ALLOW":1.0,
    "PRIORITIZE":1.5
}

REGIMES = ["TREND","MEAN_REVERSION","MOMENTUM","NEUTRAL"]

VOL_STATES = {
    "HIGH_VOL_EXPANDING":1.30,
    "LOW_VOL_COMPRESSED":0.70,
    "NORMAL_VOL":1.00,
    "BREAKOUT_EXPANSION":1.40
}

SWEEP_STATES = {
    "SWEEP_UP_REVERSAL":0.65,
    "SWEEP_DOWN_REVERSAL":0.65,
    "CLEAN_BREAKOUT":1.25,
    "NO_SWEEP":1.00
}

ENGINE_MODES = {
    "1":"SAFE",
    "2":"CONSERVATIVE",
    "3":"BALANCED",
    "4":"AGGRESSIVE",
    "5":"EXPANSION"
}

# ============================================================
# HELPERS
# ============================================================

def load_json_state(path: Path, default: Dict):
    try:
        if path.exists():
            with open(path,"r") as f:
                return json.load(f)
    except Exception:
        pass
    return default.copy()

def save_json_state(path: Path, data: Dict):
    try:
        with open(path,"w") as f:
            json.dump(data,f,indent=2)
    except Exception:
        pass

def safe_load_runtime_asset(symbol: str):
    try:
        load_runtime_asset(symbol)
        print(f"Fetched 288 candles for {symbol}")
        return True
    except Exception as e:
        print(f"[FETCH FAIL] {symbol}: {str(e)[:80]}")
        return False

def select_engine_mode():
    print("\n=== CSS ENGINE MODE SELECTOR ===")
    for k,v in ENGINE_MODES.items():
        print(f"{k}. {v}")
    choice = input("Enter choice (1-5) [default=3]: ").strip()
    return ENGINE_MODES.get(choice,"BALANCED")

def clamp_bias(v):
    return max(BIAS_MIN,min(BIAS_MAX,v))

def weighted_score(raw_score,symbol):
    return raw_score * futures_symbol_bias.get(symbol,BIAS_NEUTRAL)

# ============================================================
# PRE-TRADE PROBABILITY ENGINE (PTPOP)
# ============================================================

class PreTradeProbabilityEngine:
    """
    Predictive probability engine:
    Estimates likelihood trade ends positive before entry.
    """

    ASSET_THRESHOLDS = {
        "CRYPTO": 0.68,
        "FX": 0.72,
        "OPTIONS": 0.48,
        "FUTURES": 0.55
    }

    def estimate(
        self,
        *,
        regime_conf: float,
        vwap_mult: float,
        vol_mult: float,
        sweep_mult: float,
        raw_score: float,
        asset_class: str = "CRYPTO"
    ) -> Tuple[float,float,float,bool]:

        threshold = self.ASSET_THRESHOLDS.get(str(asset_class).upper(), 0.60)

        regime_component = regime_conf * 0.30
        vwap_component = min(vwap_mult / 1.5,1.0) * 0.20
        vol_component = min(vol_mult / 1.4,1.0) * 0.15
        sweep_component = min(sweep_mult / 1.25,1.0) * 0.15
        score_component = min(raw_score / 20.0,1.0) * 0.20

        prob_positive = (
            regime_component +
            vwap_component +
            vol_component +
            sweep_component +
            score_component
        )

        prob_positive = max(0.05,min(0.95,prob_positive))
        prob_negative = 1.0 - prob_positive

        expected_value = (prob_positive * raw_score) - (prob_negative * 8.0)

        execute = prob_positive >= threshold and expected_value > 0

        return (
            round(prob_positive,4),
            round(prob_negative,4),
            round(expected_value,4),
            execute
        )

pt_engine = PreTradeProbabilityEngine()

# ============================================================
# REGIME / STATE DETECTORS
# ============================================================

def detect_regime(symbol,asset_class):
    state = random.choice(REGIMES)
    confidence = round(random.uniform(0.45,0.95),2)

    if state == "MOMENTUM":
        risk_mult = 1.25
        priority = "PRIORITIZE"
    elif state == "TREND":
        risk_mult = 1.10
        priority = "ALLOW"
    elif state == "MEAN_REVERSION":
        risk_mult = 0.90
        priority = "REDUCE"
    else:
        risk_mult = 0.70
        priority = "BLOCK"

    return {
        "state":state,
        "confidence":confidence,
        "risk_mult":risk_mult,
        "priority":priority,
        "capital_mult":CAPITAL_MULTIPLIERS[priority]
    }

def compute_vwap_state(symbol):
    distance_pct = round(random.uniform(-3.0,3.0),2)
    slope = random.choice(["RISING","FLAT","FALLING"])

    if distance_pct > 0 and slope == "RISING":
        state = "ABOVE_RISING"
        mult = 1.25
    elif distance_pct < 0 and slope == "FALLING":
        state = "BELOW_FALLING"
        mult = 0.75
    else:
        state = "NEUTRAL"
        mult = 1.00

    return {
        "state":state,
        "mult":mult,
        "distance_pct":distance_pct
    }

def compute_volatility_state(symbol):
    state = random.choice(list(VOL_STATES.keys()))
    return {"state":state,"mult":VOL_STATES[state]}

def compute_liquidity_sweep(symbol):
    state = random.choice(list(SWEEP_STATES.keys()))
    return {"state":state,"mult":SWEEP_STATES[state]}

# ============================================================
# ENGINE MODE
# ============================================================

ENGINE_MODE = select_engine_mode()

# ============================================================
# ENGINE OBJECTS
# ============================================================

pm = PositionManager()
futures_adapter = FuturesSimAdapter(max_portfolio_allocation=5.0)
futures_pm = FuturesPositionManager(futures_adapter)

options_adapter = OptionsChainAdapter()
options_pm = OptionsPositionManager()
options_intel = OptionsIntelligenceEngine()

# ============================================================
# STATE LOAD
# ============================================================

futures_symbol_bias = load_json_state(
    FUTURES_BIAS_FILE,
    {s:1.0 for s in FUTURES_SYMBOLS}
)

futures_loss_streak = load_json_state(
    FUTURES_LOSS_FILE,
    {s:0 for s in FUTURES_SYMBOLS}
)

# ============================================================
# PNL TRACKERS
# ============================================================

crypto_pnl = {s:0.0 for s in SYMBOLS}
crypto_trades = {s:0 for s in SYMBOLS}
crypto_wins = {s:0 for s in SYMBOLS}

fx_pnl = {s:0.0 for s in FX_SYMBOLS}
fx_trades = {s:0 for s in FX_SYMBOLS}
fx_wins = {s:0 for s in FX_SYMBOLS}

options_pnl = {s:0.0 for s in OPTION_SYMBOLS}
options_trades = {s:0 for s in OPTION_SYMBOLS}
options_wins = {s:0 for s in OPTION_SYMBOLS}

futures_realized_pnl = {s:0.0 for s in FUTURES_SYMBOLS}
futures_trade_count = {s:0 for s in FUTURES_SYMBOLS}
futures_win_count = {s:0 for s in FUTURES_SYMBOLS}

futures_lifetime_total = 0.0
last_trade = "NONE"
cycle = 0

# ============================================================
# REINFORCEMENT FUNCTIONS
# ============================================================

def apply_bias_decay():
    for symbol,current in list(futures_symbol_bias.items()):
        if current > BIAS_NEUTRAL:
            current -= ((current-BIAS_NEUTRAL)*BIAS_DECAY_RATE)
        elif current < BIAS_NEUTRAL:
            current += ((BIAS_NEUTRAL-current)*BIAS_DECAY_RATE)
        futures_symbol_bias[symbol] = clamp_bias(current)

def update_reinforcement(symbol,pnl):
    current = futures_symbol_bias.get(symbol,BIAS_NEUTRAL)

    if pnl > 0:
        futures_loss_streak[symbol] = 0
        current *= BIAS_REWARD_MULT
    else:
        futures_loss_streak[symbol] += 1
        streak = futures_loss_streak[symbol]

        if streak >= 3:
            current *= BIAS_LOSS_PENALTY_3
        elif streak == 2:
            current *= BIAS_LOSS_PENALTY_2
        else:
            current *= BIAS_LOSS_PENALTY_1

    futures_symbol_bias[symbol] = clamp_bias(current)

# ============================================================
# EXECUTION FUNCTION WITH PROBABILITY GATE
# ============================================================

def execute_trade(asset_class, symbol, score, eff_mult):
    global futures_lifetime_total, last_trade

    if score < 10:
        return

    pnl = round(random.uniform(-20,20) * eff_mult,4)
    last_trade = f"{symbol} {pnl:+.4f}"

    if asset_class == "CRYPTO":
        crypto_pnl[symbol] += pnl
        crypto_trades[symbol] += 1
        if pnl > 0:
            crypto_wins[symbol] += 1

    elif asset_class == "FX":
        fx_pnl[symbol] += pnl
        fx_trades[symbol] += 1
        if pnl > 0:
            fx_wins[symbol] += 1

    elif asset_class == "OPTIONS":
        options_pnl[symbol] += pnl
        options_trades[symbol] += 1
        if pnl > 0:
            options_wins[symbol] += 1

    elif asset_class == "FUTURES":
        futures_realized_pnl[symbol] += pnl
        futures_trade_count[symbol] += 1
        futures_lifetime_total += pnl
        if pnl > 0:
            futures_win_count[symbol] += 1
        update_reinforcement(symbol,pnl)

    print(f"[{asset_class} EXECUTED] {symbol} pnl={pnl:+.4f}")

# ============================================================
# TOTALS
# ============================================================

def get_total_pnl():
    return round(
        sum(crypto_pnl.values()) +
        sum(fx_pnl.values()) +
        sum(options_pnl.values()) +
        sum(futures_realized_pnl.values()),
        4
    )

def get_top_winner():
    combined = {}
    combined.update(crypto_pnl)
    combined.update(fx_pnl)
    combined.update(options_pnl)
    combined.update(futures_realized_pnl)
    return max(combined.items(), key=lambda x:x[1])

def get_top_loser():
    combined = {}
    combined.update(crypto_pnl)
    combined.update(fx_pnl)
    combined.update(options_pnl)
    combined.update(futures_realized_pnl)
    return min(combined.items(), key=lambda x:x[1])

# ============================================================
# OPTIONS EXECUTION ENGINE
# ============================================================

def execute_intelligent_option_trade(
    option_symbol_stub,
    reg,
    vw,
    vol,
    sw,
    cycle,
    eff
):
    global last_trade

    if reg["priority"] == "BLOCK":
        return

    if vw["distance_pct"] >= 0:
        direction = "CALL"
    else:
        direction = "PUT"

    underlying_symbol = option_symbol_stub.split("-")[0]

    underlying_rows = [{
        "symbol": underlying_symbol,
        "price": round(random.uniform(90,250),2)
    }]

    option_rows = options_adapter.fetch_option_rows(underlying_rows)

    if not option_rows:
        return

    raw_score = round(random.uniform(8,18),2)
    signal_score = (
        raw_score *
        reg["risk_mult"] *
        vw["mult"] *
        vol["mult"] *
        sw["mult"]
    )

    prob_pos, prob_neg, ev, allow_trade = pt_engine.estimate(
        regime_conf=reg["confidence"],
        vwap_mult=vw["mult"],
        vol_mult=vol["mult"],
        sweep_mult=sw["mult"],
        raw_score=signal_score,
        asset_class="OPTIONS"
    )

    if not allow_trade:
        print(
            f"[OPTIONS REJECTED] {underlying_symbol} "
            f"P+={prob_pos:.2%} EV={ev:+.2f}"
        )
        return

    selected = options_intel.select_best_option(
        options=option_rows,
        underlying_price=underlying_rows[0]["price"],
        score=signal_score,
        tier="ELITE" if signal_score > 16 else "QUALIFIED",
        direction=direction
    )

    if not selected:
        return

    option_symbol = (
        f"{underlying_symbol}-"
        f"{selected['option_type'][0]}-"
        f"{int(selected['strike'])}"
    )

    open_result = options_pm.open_long_option(
        option_symbol=option_symbol,
        underlying_symbol=underlying_symbol,
        option_type=selected["option_type"],
        strike=selected["strike"],
        expiry=selected["expiry"],
        entry_price=selected["price"],
        contracts=1,
        current_cycle=cycle,
        confidence=prob_pos,
        tier=selected.get("selection_tier","WATCH"),
        note=f"PTPOP={prob_pos:.2%}"
    )

    if open_result["status"] == "OPENED":
        pnl_seed = round(random.uniform(-8,15) * eff,4)

        options_pnl[option_symbol_stub] += pnl_seed
        options_trades[option_symbol_stub] += 1

        if pnl_seed > 0:
            options_wins[option_symbol_stub] += 1

        last_trade = option_symbol

        print(
            f"[OPTIONS EXECUTED] {option_symbol} "
            f"{direction} P+={prob_pos:.2%} EV={ev:+.2f}"
        )

# ============================================================
# MAIN LOOP
# ============================================================

while True:
    cycle += 1
    print(f"\n=== Cycle {cycle} | {datetime.now()} ===")

    apply_bias_decay()

    total = get_total_pnl()
    winner_sym, winner_val = get_top_winner()
    loser_sym, loser_val = get_top_loser()

    print("\n--- LIVE EXECUTION SUMMARY ---")
    print(f"TOTAL PNL: {total:+.4f}")
    print(f"CRYPTO OPEN: {sum(crypto_trades.values())} | PNL {sum(crypto_pnl.values()):+.4f}")
    print(f"FX OPEN: {sum(fx_trades.values())} | PNL {sum(fx_pnl.values()):+.4f}")
    print(f"OPTIONS OPEN: {sum(options_trades.values())} | PNL {sum(options_pnl.values()):+.4f}")
    print(f"FUTURES OPEN: {sum(futures_trade_count.values())} | PNL {sum(futures_realized_pnl.values()):+.4f}")
    print(f"TOP WINNER: {winner_sym} {winner_val:+.4f}")
    print(f"TOP LOSER: {loser_sym} {loser_val:+.4f}")
    print(f"LAST TRADE: {last_trade}")
    print("-" * 60)

    regime_board = []
    vwap_board = []
    volatility_board = []
    sweep_board = []
    effective_board = []

    # ========================================================
    # CRYPTO EXECUTION WITH PTPOP
    # ========================================================
    for s in SYMBOLS:
        safe_load_runtime_asset(s)

        reg = detect_regime(s, "CRYPTO")
        vw = compute_vwap_state(s)
        vol = compute_volatility_state(s)
        sw = compute_liquidity_sweep(s)

        eff = reg["capital_mult"] * vw["mult"] * vol["mult"] * sw["mult"]

        regime_board.append((s, "CRYPTO", reg))
        vwap_board.append((s, vw))
        volatility_board.append((s, vol))
        sweep_board.append((s, sw))
        effective_board.append(
            (s, "CRYPTO", reg["priority"], vw["state"], vol["state"], sw["state"], eff)
        )

        if reg["priority"] == "BLOCK":
            continue

        raw_score = round(random.uniform(8,18),2)
        signal_score = raw_score * reg["risk_mult"] * vw["mult"] * vol["mult"] * sw["mult"]

        prob_pos, prob_neg, ev, allow_trade = pt_engine.estimate(
            regime_conf=reg["confidence"],
            vwap_mult=vw["mult"],
            vol_mult=vol["mult"],
            sweep_mult=sw["mult"],
            raw_score=signal_score,
            asset_class="CRYPTO"
        )

        if not allow_trade:
            print(f"[CRYPTO REJECTED] {s} P+={prob_pos:.2%} EV={ev:+.2f}")
            continue

        execute_trade("CRYPTO", s, round(signal_score,2), eff)

    # ========================================================
    # FX EXECUTION WITH PTPOP
    # ========================================================
    for s in FX_SYMBOLS:
        reg = detect_regime(s, "FX")
        vw = compute_vwap_state(s)
        vol = compute_volatility_state(s)
        sw = compute_liquidity_sweep(s)

        eff = reg["capital_mult"] * vw["mult"] * vol["mult"] * sw["mult"]

        regime_board.append((s, "FX", reg))
        vwap_board.append((s, vw))
        volatility_board.append((s, vol))
        sweep_board.append((s, sw))
        effective_board.append(
            (s, "FX", reg["priority"], vw["state"], vol["state"], sw["state"], eff)
        )

        if reg["priority"] == "BLOCK":
            continue

        raw_score = round(random.uniform(8,18),2)
        signal_score = raw_score * reg["risk_mult"] * vw["mult"] * vol["mult"] * sw["mult"]

        prob_pos, prob_neg, ev, allow_trade = pt_engine.estimate(
            regime_conf=reg["confidence"],
            vwap_mult=vw["mult"],
            vol_mult=vol["mult"],
            sweep_mult=sw["mult"],
            raw_score=signal_score,
            asset_class="FX"
        )

        if not allow_trade:
            print(f"[FX REJECTED] {s} P+={prob_pos:.2%} EV={ev:+.2f}")
            continue

        execute_trade("FX", s, round(signal_score,2), eff)

    # ========================================================
    # OPTIONS EXECUTION WITH INTELLIGENCE + PTPOP
    # ========================================================
    for s in OPTION_SYMBOLS:
        reg = detect_regime(s, "OPTIONS")
        vw = compute_vwap_state(s)
        vol = compute_volatility_state(s)
        sw = compute_liquidity_sweep(s)

        eff = reg["capital_mult"] * vw["mult"] * vol["mult"] * sw["mult"]

        regime_board.append((s, "OPTIONS", reg))
        vwap_board.append((s, vw))
        volatility_board.append((s, vol))
        sweep_board.append((s, sw))
        effective_board.append(
            (s, "OPTIONS", reg["priority"], vw["state"], vol["state"], sw["state"], eff)
        )

        execute_intelligent_option_trade(
            s, reg, vw, vol, sw, cycle, eff
        )

    # ========================================================
    # FUTURES EXECUTION WITH PTPOP
    # ========================================================
    if random.random() < 0.35:
        symbol = random.choice(FUTURES_SYMBOLS)

        reg = detect_regime(symbol, "FUTURES")
        vw = compute_vwap_state(symbol)
        vol = compute_volatility_state(symbol)
        sw = compute_liquidity_sweep(symbol)

        eff = reg["capital_mult"] * vw["mult"] * vol["mult"] * sw["mult"]

        regime_board.append((symbol, "FUTURES", reg))
        vwap_board.append((symbol, vw))
        volatility_board.append((symbol, vol))
        sweep_board.append((symbol, sw))
        effective_board.append(
            (symbol, "FUTURES", reg["priority"], vw["state"], vol["state"], sw["state"], eff)
        )

        if reg["priority"] != "BLOCK":
            raw_score = round(random.uniform(8,18),2)
            weighted = weighted_score(raw_score, symbol)

            signal_score = (
                weighted *
                reg["risk_mult"] *
                vw["mult"] *
                vol["mult"] *
                sw["mult"]
            )

            prob_pos, prob_neg, ev, allow_trade = pt_engine.estimate(
                regime_conf=reg["confidence"],
                vwap_mult=vw["mult"],
                vol_mult=vol["mult"],
                sweep_mult=sw["mult"],
                raw_score=signal_score,
                asset_class="FUTURES"
            )

            if allow_trade:
                execute_trade("FUTURES", symbol, round(signal_score,2), eff)
            else:
                print(
                    f"[FUTURES REJECTED] {symbol} "
                    f"P+={prob_pos:.2%} EV={ev:+.2f}"
                )

    # ========================================================
    # SAVE STATE
    # ========================================================
    save_json_state(FUTURES_BIAS_FILE, futures_symbol_bias)
    save_json_state(FUTURES_LOSS_FILE, futures_loss_streak)

    # ========================================================
    # DASHBOARD BOARDS
    # ========================================================
    print("\n--- LIQUIDITY SWEEP BOARD ---")
    for sym, sw in sweep_board[:12]:
        print(f"{sym} | {sw['state']} | {sw['mult']:.2f}x")

    print("\n--- VWAP BOARD ---")
    for sym, vw in vwap_board[:12]:
        print(f"{sym} | {vw['distance_pct']:+.2f}% | {vw['state']}")

    print("\n--- VOLATILITY BOARD ---")
    for sym, vol in volatility_board[:12]:
        print(f"{sym} | {vol['state']} | {vol['mult']:.2f}x")

    print("\n--- UNIVERSAL EFFECTIVE BOARD ---")
    for sym, cls, pri, vwstate, volstate, swstate, eff in effective_board[:12]:
        print(
            f"{sym} | {cls} | {pri} | "
            f"{vwstate} | {volstate} | {swstate} | Eff {eff:.2f}x"
        )

    print("\n--- FUTURES SYMBOL BIAS ---")
    print(futures_symbol_bias)

    time.sleep(CYCLE_SLEEP)